# niuload

niuload is a Python module for balanced loading of large language models across multiple GPUs.
This package can be used during training and inference.

